import io
from decimal import Decimal
from pathlib import Path

from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand

from piese.models import Anunt, Cerere, Oferta

FOTO_DIR = Path(__file__).resolve().parents[2] / "seed_images"

# (titlu, categorie, stare, marca, model, an, cod, pret, oras, telefon, descriere, tip)
DATE = [
    ("Discuri de frână față 288 mm", "Frâne", "Nouă", "Volkswagen", "Golf 5", 2006, "1K0 615 301 AA", "189.00", "Brașov", "0722 100 201",
     "Set 2 discuri ventilate, diametru 288 mm. Sigilate, în cutie. Se potrivesc și pe Audi A3 8P și Skoda Octavia 2.", "disc"),
    ("Plăcuțe de frână spate", "Frâne", "Nouă", "Dacia", "Logan", 2012, "440606 3AA", "75.00", "București", "0733 200 302",
     "Set plăcuțe spate, marcă recunoscută. Montaj simplu. Pot trimite prin curier.", "placute"),
    ("Alternator 120A", "Electrice", "Recondiționată", "BMW", "Seria 3 E90", 2008, "12317799783", "420.00", "Cluj-Napoca", "0744 300 403",
     "Alternator recondiționat complet, rulmenți și perii noi. Garanție 6 luni.", "alternator"),
    ("Far dreapta xenon complet", "Electrice", "Second-hand", "Audi", "A4 B8", 2010, "8K0 941 004 C", "650.00", "Timișoara", "0755 400 504",
     "Far xenon cu balast și modul. Fără ancore rupte, sticla fără zgârieturi. Demontat din mașină cu 150.000 km.", "far"),
    ("Set amortizoare față", "Suspensie", "Nouă", "Ford", "Focus 2", 2009, "1 523 217", "340.00", "Iași", "0766 500 605",
     "Două amortizoare cu gaz, față stânga și dreapta. Garanție 2 ani la producător.", "amortizor"),
    ("Kit distribuție cu pompă de apă", "Motor", "Nouă", "Renault", "Megane 3 1.5 dCi", 2011, "130C17575R", "395.00", "Brașov", "0722 100 201",
     "Kit complet: curea, role, pompă de apă. Pentru motor K9K. Factură și garanție.", "distributie"),
    ("Capotă motor gri metalizat", "Caroserie", "Second-hand", "Opel", "Astra H", 2007, "93177205", "280.00", "Sibiu", "0777 600 706",
     "Capotă fără lovituri, vopsea originală gri. Preluare personală sau transport.", "capota"),
    ("Jante aliaj 16\" 5x112", "Roți și anvelope", "Second-hand", "Volkswagen", "Passat B6", 2008, "3C0 601 025", "900.00", "Oradea", "0788 700 807",
     "Set 4 jante de 16 inch, ET 42, fără îndreptări. Ușoare urme de folosire. Fără anvelope.", "jante"),
    ("Anvelope iarnă 205/55 R16", "Roți și anvelope", "Second-hand", "Universal", "-", None, "205/55R16 91H", "520.00", "Cluj-Napoca", "0744 300 403",
     "Set 4 anvelope de iarnă, anul 2022, aproximativ 6 mm bandă de rulare.", "anvelope"),
    ("Volan piele cu comenzi", "Interior", "Second-hand", "Skoda", "Octavia 2", 2010, "1Z0 419 091", "310.00", "Constanța", "0799 800 908",
     "Volan în trei spițe, piele în stare bună, cu comenzi audio. Airbag nu este inclus.", "volan"),
    ("Radiator apă", "Motor", "Nouă", "Dacia", "Duster", 2014, "214100 8EA1A", "260.00", "Pitești", "0733 200 302",
     "Radiator nou din aluminiu, compatibil cu 1.5 dCi și 1.6 benzină. Se livrează în cutie.", "radiator"),
    ("Cutie de viteze manuală 5 trepte", "Motor", "Recondiționată", "Toyota", "Corolla E12", 2004, "MTM 1.4 D-4D", "1500.00", "Ploiești", "0722 111 909",
     "Cutie recondiționată, testată pe stand. Se poate verifica înainte de cumpărare.", "cutie"),
]


def poza(tip):
    """Întâi caută o fotografie reală în piese/seed_images/<tip>.jpg, altfel desenează o ilustrație."""
    for ext in ("jpg", "jpeg", "png", "webp"):
        f = FOTO_DIR / f"{tip}.{ext}"
        if f.exists():
            return ContentFile(f.read_bytes()), ext
    try:
        from .ilustratii import ilustratie
    except ImportError:
        return None, None
    buf = io.BytesIO()
    ilustratie(tip).save(buf, "JPEG", quality=90)
    return ContentFile(buf.getvalue()), "jpg"


# (titlu, categorie, marca, model, an, cod, buget, oras, telefon, descriere)
CERERI = [
    ("Caut far stânga Golf 5", "Electrice", "Volkswagen", "Golf 5", 2006, "1K6 941 007", "300.00", "Brașov", "0730 111 001",
     "Caut far stânga, fără cleme rupte. Pot ridica personal."),
    ("Caut oglindă electrică dreapta", "Caroserie", "Ford", "Focus 2", 2009, "", "150.00", "Iași", "0730 111 002",
     "Oglindă dreapta cu reglaj electric, culoare neagră sau gri."),
    ("Cutie automată, stare bună", "Motor", "BMW", "Seria 3 E90", 2008, "GA6HP19Z", "2500.00", "București", "0730 111 003",
     "Caut cutie automată funcțională, de preferat cu istoric de service."),
    ("Set 4 jante de 16 inch", "Roți și anvelope", "Volkswagen", "Passat B6", 2008, "", "1200.00", "Cluj-Napoca", "0730 111 004",
     "Jante aliaj 5x112, fără îndreptări."),
    ("Pompă de injecție 1.9 TDI", "Motor", "Skoda", "Octavia 2", 2010, "", "900.00", "Sibiu", "0730 111 005",
     "Caut pompă de injecție testată, cu garanție."),
]


class Command(BaseCommand):
    help = "Creează anunțuri și cereri fictive pentru testare (conturi: demo / demo12345 și client / client12345)."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Șterge întâi anunțurile demo și cererile client")

    def handle(self, *args, **opts):
        User = get_user_model()
        demo, nou = User.objects.get_or_create(username="demo", defaults={"email": "demo@exemplu.ro"})
        if nou:
            demo.set_password("demo12345")
            demo.save()
        client, nou = User.objects.get_or_create(username="client", defaults={"email": "client@exemplu.ro"})
        if nou:
            client.set_password("client12345")
            client.save()
        if opts["reset"]:
            demo.anunturi.all().delete()
            client.cereri.all().delete()

        mesaj = []
        jante = None
        if not demo.anunturi.exists():
            for t, cat, stare, marca, model, an, cod, pret, oras, tel, desc, tip in DATE:
                a = Anunt(user=demo, titlu=t, categorie=cat, stare=stare, marca=marca, model=model,
                          an=an, cod_piesa=cod, pret=Decimal(pret), oras=oras, telefon=tel, descriere=desc)
                fisier, ext = poza(tip)
                if fisier:
                    a.imagine.save(f"{tip}.{ext}", fisier, save=False)
                a.save()
                if tip == "jante":
                    jante = a
            mesaj.append(f"{len(DATE)} anunțuri")
        if not client.cereri.exists():
            create = []
            for t, cat, marca, model, an, cod, buget, oras, tel, desc in CERERI:
                create.append(Cerere.objects.create(
                    user=client, titlu=t, categorie=cat, marca=marca, model=model, an=an, cod_piesa=cod,
                    buget=Decimal(buget), oras=oras, telefon=tel, descriere=desc))
            jante = jante or demo.anunturi.filter(titlu__startswith="Jante").first()
            Oferta.objects.create(cerere=create[3], user=demo, anunt=jante, pret=Decimal("950.00"),
                                  telefon="0788 700 807", mesaj="Am exact setul acesta, fără îndreptări. Pot trimite poze.")
            mesaj.append(f"{len(CERERI)} cereri (una cu ofertă)")
        if mesaj:
            self.stdout.write(self.style.SUCCESS("Gata: " + " și ".join(mesaj) + ". Conturi: demo / demo12345, client / client12345"))
        else:
            self.stdout.write("Există deja date demo. Rulează cu --reset ca să le refaci.")

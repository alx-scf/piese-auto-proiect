import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

CATEGORII = [("Motor", "Motor"), ("Frâne", "Frâne"), ("Suspensie", "Suspensie"), ("Caroserie", "Caroserie"),
             ("Electrice", "Electrice"), ("Interior", "Interior"), ("Roți și anvelope", "Roți și anvelope"),
             ("Altele", "Altele")]


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("piese", "0001_initial"),
    ]
    operations = [
        migrations.CreateModel(
            name="Cerere",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("titlu", models.CharField(max_length=140)),
                ("descriere", models.TextField(blank=True)),
                ("categorie", models.CharField(choices=CATEGORII, max_length=40)),
                ("stare", models.CharField(blank=True, max_length=20, verbose_name="Stare dorită")),
                ("marca", models.CharField(blank=True, max_length=60, verbose_name="Marcă")),
                ("model", models.CharField(blank=True, max_length=60)),
                ("an", models.PositiveSmallIntegerField(blank=True, null=True)),
                ("cod_piesa", models.CharField(blank=True, max_length=60, verbose_name="Cod piesă")),
                ("buget", models.DecimalField(blank=True, decimal_places=2, max_digits=9, null=True,
                                              verbose_name="Buget maxim (lei)")),
                ("oras", models.CharField(blank=True, max_length=80, verbose_name="Localitate")),
                ("telefon", models.CharField(blank=True, max_length=30)),
                ("status", models.CharField(choices=[("deschisa", "Deschisă"), ("rezolvata", "Rezolvată")],
                                            default="deschisa", max_length=12)),
                ("creat", models.DateTimeField(auto_now_add=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="cereri",
                                           to=settings.AUTH_USER_MODEL)),
            ],
            options={"verbose_name_plural": "cereri", "ordering": ["-creat"]},
        ),
        migrations.CreateModel(
            name="Oferta",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("pret", models.DecimalField(decimal_places=2, max_digits=9, verbose_name="Preț oferit (lei)")),
                ("telefon", models.CharField(blank=True, max_length=30)),
                ("mesaj", models.TextField(blank=True)),
                ("acceptata", models.BooleanField(default=False)),
                ("creat", models.DateTimeField(auto_now_add=True)),
                ("anunt", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                                            related_name="+", to="piese.anunt")),
                ("cerere", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="oferte",
                                             to="piese.cerere")),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="oferte",
                                           to=settings.AUTH_USER_MODEL)),
            ],
            options={"verbose_name_plural": "oferte", "ordering": ["creat"]},
        ),
    ]

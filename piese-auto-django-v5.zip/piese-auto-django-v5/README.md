# Piese Auto (Django) - v5
Pagina de start, anunțuri, cereri de piese și oferte ("fulfill").

    python -m venv venv
    venv\Scripts\activate        # Mac/Linux: source venv/bin/activate
    pip install -r requirements.txt
    python manage.py migrate
    python manage.py seed        # opțional: anunțuri și cereri fictive
    python manage.py createsuperuser
    python manage.py runserver
Deschide http://127.0.0.1:8000

## Pornire rapida
Windows: dublu-click pe start.bat. Mac/Linux: start.command. Vezi CITESTE-MA.txt.

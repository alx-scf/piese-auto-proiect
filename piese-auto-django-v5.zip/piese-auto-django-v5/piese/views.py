from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.views.decorators.http import require_POST
from django.views.generic import (CreateView, DeleteView, DetailView, ListView,
                                  TemplateView, UpdateView)

from .forms import AnuntForm, CerereForm, OfertaForm
from .models import Anunt, Cerere, Oferta
from .optiuni import MARCI, ORASE


def filtreaza(qs, g):
    """Aceleași criterii pentru anunțuri și cereri."""
    if q := g.get("q", "").strip():
        qs = qs.filter(Q(titlu__icontains=q) | Q(cod_piesa__icontains=q) | Q(descriere__icontains=q))
    if g.get("categorie"):
        qs = qs.filter(categorie=g["categorie"])
    if g.get("marca"):
        qs = qs.filter(marca=g["marca"])
    if g.get("oras"):
        qs = qs.filter(oras=g["oras"])
    return qs


class FiltreMixin:
    def get_context_data(self, **kw):
        return super().get_context_data(categorii=[c for c, _ in Anunt.CATEGORII],
                                        marci=MARCI, orase=ORASE, **kw)


class Proprietar(LoginRequiredMixin, UserPassesTestMixin):
    def test_func(self):
        return self.get_object().user == self.request.user


# ---------- Acasă ----------
class Acasa(TemplateView):
    template_name = "acasa.html"

    def get_context_data(self, **kw):
        return super().get_context_data(
            anunturi=Anunt.objects.all()[:6],
            cereri=Cerere.objects.filter(status="deschisa")[:5], **kw)


# ---------- Anunțuri ----------
class Lista(FiltreMixin, ListView):
    model = Anunt
    template_name = "lista.html"
    context_object_name = "anunturi"
    paginate_by = 24

    def get_queryset(self):
        g = self.request.GET
        qs = filtreaza(super().get_queryset(), g)
        if g.get("pmax"):
            try:
                qs = qs.filter(pret__lte=g["pmax"])
            except (ValueError, ValidationError):
                pass
        return qs


class AnunturileMele(LoginRequiredMixin, Lista):
    def get_queryset(self):
        return Anunt.objects.filter(user=self.request.user)

    def get_context_data(self, **kw):
        return super().get_context_data(mele=True, **kw)


class Detaliu(DetailView):
    model = Anunt
    template_name = "detaliu.html"
    context_object_name = "a"


class Nou(LoginRequiredMixin, CreateView):
    model = Anunt
    form_class = AnuntForm
    template_name = "formular.html"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class Editeaza(Proprietar, UpdateView):
    model = Anunt
    form_class = AnuntForm
    template_name = "formular.html"


class Sterge(Proprietar, DeleteView):
    model = Anunt
    template_name = "sterge.html"
    success_url = reverse_lazy("anunturile_mele")


# ---------- Cereri ----------
class ListaCereri(FiltreMixin, ListView):
    model = Cerere
    template_name = "cereri_lista.html"
    context_object_name = "cereri"
    paginate_by = 20

    def get_queryset(self):
        g = self.request.GET
        qs = filtreaza(super().get_queryset(), g)
        if g.get("status") != "toate":
            qs = qs.filter(status="deschisa")
        return qs


class CererileMele(LoginRequiredMixin, ListaCereri):
    def get_queryset(self):
        return Cerere.objects.filter(user=self.request.user)

    def get_context_data(self, **kw):
        return super().get_context_data(mele=True, **kw)


class CerereDetaliu(DetailView):
    model = Cerere
    template_name = "cerere_detaliu.html"
    context_object_name = "c"

    def get_context_data(self, **kw):
        ctx = super().get_context_data(**kw)
        c, u = self.object, self.request.user
        if u.is_authenticated and u != c.user:
            ctx["oferta_mea"] = c.oferte.filter(user=u).first()
            if c.status == "deschisa" and not ctx["oferta_mea"] and "form" not in ctx:
                ctx["form"] = OfertaForm(user=u)
        if u == c.user:
            ctx["oferte"] = c.oferte.select_related("user", "anunt")
        ctx["nr_oferte"] = c.oferte.count()
        return ctx

    def post(self, request, *args, **kwargs):
        """Cineva îndeplinește cererea: trimite o ofertă."""
        self.object = c = self.get_object()
        if not request.user.is_authenticated:
            return redirect(f"{reverse('login')}?next={request.path}")
        if c.user == request.user or c.status != "deschisa":
            raise PermissionDenied
        if c.oferte.filter(user=request.user).exists():
            messages.info(request, "Ai trimis deja o ofertă la această cerere.")
            return redirect(c)
        form = OfertaForm(request.POST, user=request.user)
        if form.is_valid():
            o = form.save(commit=False)
            o.cerere, o.user = c, request.user
            o.save()
            messages.success(request, "Oferta ta a fost trimisă. Solicitantul te poate contacta.")
            return redirect(c)
        return self.render_to_response(self.get_context_data(form=form))


class CerereNoua(LoginRequiredMixin, CreateView):
    model = Cerere
    form_class = CerereForm
    template_name = "cerere_form.html"

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class CerereEditeaza(Proprietar, UpdateView):
    model = Cerere
    form_class = CerereForm
    template_name = "cerere_form.html"


class CerereSterge(Proprietar, DeleteView):
    model = Cerere
    template_name = "sterge.html"
    success_url = reverse_lazy("cererile_mele")


@login_required
@require_POST
def accepta_oferta(request, pk):
    o = get_object_or_404(Oferta.objects.select_related("cerere"), pk=pk, cerere__user=request.user)
    o.cerere.oferte.update(acceptata=False)
    o.acceptata = True
    o.save(update_fields=["acceptata"])
    o.cerere.status = "rezolvata"
    o.cerere.save(update_fields=["status"])
    messages.success(request, "Cererea a fost marcată ca rezolvată.")
    return redirect(o.cerere)


@login_required
@require_POST
def redeschide_cerere(request, pk):
    c = get_object_or_404(Cerere, pk=pk, user=request.user)
    c.oferte.update(acceptata=False)
    c.status = "deschisa"
    c.save(update_fields=["status"])
    return redirect(c)


# ---------- Conturi ----------
class Inregistrare(CreateView):
    form_class = UserCreationForm
    template_name = "registration/signup.html"
    success_url = reverse_lazy("login")

from django.conf import settings
from django.db import models
from django.urls import reverse


class Anunt(models.Model):
    CATEGORII = [(c, c) for c in
                 ["Motor", "Frâne", "Suspensie", "Caroserie", "Electrice", "Interior", "Roți și anvelope", "Altele"]]
    STARI = [(s, s) for s in ["Nouă", "Second-hand", "Recondiționată"]]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="anunturi")
    titlu = models.CharField(max_length=140)
    descriere = models.TextField(blank=True)
    categorie = models.CharField(max_length=40, choices=CATEGORII)
    stare = models.CharField(max_length=20, choices=STARI)
    marca = models.CharField("Marcă", max_length=60, blank=True)
    model = models.CharField(max_length=60, blank=True)
    an = models.PositiveSmallIntegerField(null=True, blank=True)
    cod_piesa = models.CharField("Cod piesă", max_length=60, blank=True)
    pret = models.DecimalField("Preț (lei)", max_digits=9, decimal_places=2)
    oras = models.CharField("Localitate", max_length=80, blank=True)
    telefon = models.CharField(max_length=30, blank=True)
    imagine = models.ImageField("Fotografie", upload_to="anunturi/", blank=True)
    creat = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creat"]
        verbose_name_plural = "anunțuri"

    def __str__(self):
        return self.titlu

    def get_absolute_url(self):
        return reverse("detaliu", args=[self.pk])


class Cerere(models.Model):
    STATUSURI = [("deschisa", "Deschisă"), ("rezolvata", "Rezolvată")]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="cereri")
    titlu = models.CharField(max_length=140)
    descriere = models.TextField(blank=True)
    categorie = models.CharField(max_length=40, choices=Anunt.CATEGORII)
    stare = models.CharField("Stare dorită", max_length=20, blank=True)
    marca = models.CharField("Marcă", max_length=60, blank=True)
    model = models.CharField(max_length=60, blank=True)
    an = models.PositiveSmallIntegerField(null=True, blank=True)
    cod_piesa = models.CharField("Cod piesă", max_length=60, blank=True)
    buget = models.DecimalField("Buget maxim (lei)", max_digits=9, decimal_places=2, null=True, blank=True)
    oras = models.CharField("Localitate", max_length=80, blank=True)
    telefon = models.CharField(max_length=30, blank=True)
    status = models.CharField(max_length=12, choices=STATUSURI, default="deschisa")
    creat = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creat"]
        verbose_name_plural = "cereri"

    def __str__(self):
        return self.titlu

    def get_absolute_url(self):
        return reverse("cerere_detaliu", args=[self.pk])


class Oferta(models.Model):
    cerere = models.ForeignKey(Cerere, on_delete=models.CASCADE, related_name="oferte")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="oferte")
    anunt = models.ForeignKey(Anunt, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")
    pret = models.DecimalField("Preț oferit (lei)", max_digits=9, decimal_places=2)
    telefon = models.CharField(max_length=30, blank=True)
    mesaj = models.TextField(blank=True)
    acceptata = models.BooleanField(default=False)
    creat = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["creat"]
        verbose_name_plural = "oferte"

    def __str__(self):
        return f"{self.user} -> {self.cerere}"

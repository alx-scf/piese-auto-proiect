"""Liste de opțiuni folosite în formulare și filtre. Adaugă aici ce lipsește."""
MARCI = sorted([
    "Alfa Romeo", "Audi", "BMW", "Chevrolet", "Citroën", "Dacia", "Fiat", "Ford", "Honda", "Hyundai",
    "Jeep", "Kia", "Land Rover", "Lexus", "Mazda", "Mercedes-Benz", "Mini", "Mitsubishi", "Nissan",
    "Opel", "Peugeot", "Porsche", "Renault", "Seat", "Skoda", "Subaru", "Suzuki", "Toyota",
    "Volkswagen", "Volvo",
]) + ["Universal"]

ORASE = sorted([
    "Alba Iulia", "Arad", "Bacău", "Baia Mare", "Bistrița", "Botoșani", "Brăila", "Brașov", "București",
    "Buzău", "Călărași", "Cluj-Napoca", "Constanța", "Craiova", "Deva", "Focșani", "Galați", "Giurgiu",
    "Iași", "Oradea", "Piatra Neamț", "Pitești", "Ploiești", "Râmnicu Vâlcea", "Reșița", "Satu Mare",
    "Sibiu", "Slatina", "Suceava", "Târgoviște", "Târgu Mureș", "Timișoara", "Tulcea", "Vaslui", "Zalău",
])

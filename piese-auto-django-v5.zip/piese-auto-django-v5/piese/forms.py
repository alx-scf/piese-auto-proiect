from datetime import date

from django import forms

from .models import Anunt, Cerere, Oferta
from .optiuni import MARCI, ORASE


class CampuriComune(forms.ModelForm):
    """Marcă, localitate și an: doar alegere din listă, fără scriere liberă."""
    marca = forms.ChoiceField(label="Marcă", choices=[("", "Alege marca")] + [(m, m) for m in MARCI])
    oras = forms.ChoiceField(label="Localitate", choices=[("", "Alege localitatea")] + [(o, o) for o in ORASE])
    an = forms.TypedChoiceField(label="An", required=False, coerce=int, empty_value=None, choices=[])

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        ani = range(date.today().year, 1969, -1)
        self.fields["an"].choices = [("", "Alege anul")] + [(a, a) for a in ani]


class AnuntForm(CampuriComune):
    class Meta:
        model = Anunt
        fields = ["titlu", "categorie", "stare", "marca", "model", "an", "cod_piesa",
                  "pret", "oras", "telefon", "imagine", "descriere"]


class CerereForm(CampuriComune):
    stare = forms.ChoiceField(label="Stare dorită", required=False, choices=[("", "Oricare")] + Anunt.STARI)
    buget = forms.DecimalField(label="Buget maxim (lei)", required=False, min_value=0, max_digits=9, decimal_places=2)

    class Meta:
        model = Cerere
        fields = ["titlu", "categorie", "stare", "marca", "model", "an", "cod_piesa",
                  "buget", "oras", "telefon", "descriere"]


class OfertaForm(forms.ModelForm):
    class Meta:
        model = Oferta
        fields = ["anunt", "pret", "telefon", "mesaj"]
        labels = {"anunt": "Leagă oferta de unul dintre anunțurile tale (opțional)", "mesaj": "Mesaj"}

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["anunt"].queryset = Anunt.objects.filter(user=user) if user else Anunt.objects.none()
        self.fields["anunt"].empty_label = "Fără anunț legat"
        self.fields["anunt"].required = False

    def clean_pret(self):
        pret = self.cleaned_data["pret"]
        if pret < 0:
            raise forms.ValidationError("Prețul nu poate fi negativ.")
        return pret

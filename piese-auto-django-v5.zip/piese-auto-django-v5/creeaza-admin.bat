@echo off
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Porneste mai intai start.bat o data.
  pause
  exit /b 1
)
echo Parola nu se vede cand o scrii. Scrie-o si apasa Enter.
venv\Scripts\python manage.py createsuperuser
pause
